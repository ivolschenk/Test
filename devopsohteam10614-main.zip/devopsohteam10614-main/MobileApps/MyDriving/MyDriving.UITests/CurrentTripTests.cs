﻿using System;
namespace MyDriving.UITests
{
	public class CurrentTripTests
	{
		public CurrentTripTests()
		{
		}

		// Simulate location change

		// Start Recording Trip
		// Stop Recording Trip
		// Summary Screen Presented
			// Enter Name
			// Don't enter name
				// Enter name in alert dialog
		// Current trip is saved
		// Check past trips for it
	}
}

