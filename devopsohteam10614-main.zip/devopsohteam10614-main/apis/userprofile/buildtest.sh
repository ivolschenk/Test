#!/bin/bash

# install dependencies
npm install

# run tests
npm run test