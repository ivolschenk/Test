﻿using System;
namespace MyDriving.UITests
{
	public class ProfileTests
	{
		// 
	}
}

