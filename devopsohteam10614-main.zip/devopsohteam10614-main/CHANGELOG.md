## [project-title] Changelog

<a name="1.1.0"></a>
1.1.0 (04/02/2019)

*Features*
- Refactored Blue/Green support in api charts
- Clean up chart parameters
- Change charts to use packages
- Remove Proctor monitoring infrastructure and replace with Bash Curl/PowerShell scripts

*Bug Fixes*
* ...

*Breaking Changes*
* ...
